insert into Cards (cardsid,cardname,annualfee,eligibility,cardtype) values ('Platinum','Platinum Card','700','Salariued employee or business','Master');
insert into Cards (cardsid,cardname,annualfee,eligibility,cardtype) values ('Fast','Millenium Card','500','Students Prepaid','Master');
insert into Cards (cardsid,cardname,annualfee,eligibility,cardtype) values ('Fuels','Fuel card','700','Salariued employee or business','VISA');

insert into Cust_Cards (cardid,custid,issuedate,expirydate,nameoncard,maxcashlimit,maxcreditlimit,outstanding,lastpayment,cvv,mobile) values ('1233-4455-1234-2345','C01001','01/01/2010','31/02/2024','John',10000,20000,8000,5500,811,'8767565902');
insert into Cust_Cards (cardid,custid,issuedate,expirydate,nameoncard,maxcashlimit,maxcreditlimit,outstanding,lastpayment,cvv,mobile) values ('1234-2255-1224-2345','C01002','01/01/2010','31/02/2024','Peter',10000,20000,8000,5500,885,'990565902');

