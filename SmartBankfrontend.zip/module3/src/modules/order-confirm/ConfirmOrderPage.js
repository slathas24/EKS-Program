import React from 'react';

function ConfirmOrder() {


    return (
        <div className="container mt-5" style={{textAlign: "center",justifyContent: "center"}}>
            <h5 style={{color:"green"}}>
            <i className="fas fa-check-circle"></i>&nbsp;
                Congratulations. You have successfully redeemed your points.<br></br>
                You will receive your vouchers in your registered mail id.
    
            </h5>
        </div>

    )
}
export default ConfirmOrder